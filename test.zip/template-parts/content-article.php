<?php
$category_list = get_the_category();
?>

<artilcle class="post">
	<a href="<?php echo get_permalink() ?>" class="item-link">
		<span class="screen-reader-text">
			<?php echo __('Перейти до статті', 'arctest') . ' ' . $post->post_title ?>
		</span>
	</a>

	<div class="img-wrap">
		<?php if (has_post_thumbnail()) {
			the_post_thumbnail('post-card', [
				'alt' 	=> trim(strip_tags(get_the_title())),
				'title' => trim(strip_tags(get_the_title())),
				'class' => 'post-img',
			]);
		} else {
		?>
			<div class="post__default-stub"></div>
		<?php } ?>
	</div>

	<?php if (!empty($category_list)) { ?>
		<div class="post__categiry-list">
			<?php foreach ($category_list as $cat) { ?>
				<div class="post__categiry-item">
					<?php echo $cat->name ?>
				</div>
			<?php } ?>
		</div>
	<?php } ?>

	<div class="post__content">
		<div class="post__meta">
			<?php
			$terms = get_the_terms(get_the_ID(), 'article-topic');
			if ($terms && !is_wp_error($terms)) {
				foreach ($terms as $term) { ?>
					<span class="post__term" data-term-id="<?php echo esc_attr($term->term_id); ?>">
						<?php echo esc_html($term->name); ?>
					</span>
			<?php };
			};
			?>
		</div>

		<h2 class="post__title">
			<?php echo the_title() ?>
		</h2>
	</div>
</artilcle>
