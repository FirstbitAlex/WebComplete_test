<?php
get_header();

$terms = get_terms([
	'taxonomy' => 'article-topic',
	'hide_empty' => false,
]);

$current_topic = '';
if (isset($_GET['topic']) && !empty($_GET['topic'])) {
	$current_topic = $_GET['topic'];
}

?>

<main id="primary">
	<section>
		<div class="container">
			<h1 class="page-title">
				<?php _e('The Journal', 'arctest'); ?>
			</h1>
		</div>
	</section>

	<section class="section">
		<div class="container">
			<nav class="filter-nav">
				<button class="filter-nav__item" data-term-id="0">
					<?php _e('All', 'arctest') ?>
				</button>

				<?php foreach ($terms as $term) { ?>
					<button class="filter-nav__item" data-term-id="<?php echo esc_attr($term->term_id); ?>">
						<?php echo esc_html($term->name); ?>
					</button>
				<?php } ?>
			</nav>

			<div class="nav-line"></div>
		</div>
	</section>

	<section class="section">
		<div class="container">
			<div class="post-list">
				<?php
				if (have_posts()) {
					while (have_posts()) {
						the_post();
						get_template_part('template-parts/content', 'article');
					};
					wp_reset_postdata();
				} else {
					get_template_part('template-parts/content', 'none');
				};
				?>
			</div>
		</div>
	</section>

	<section class="section section--load-more">
		<div class="container">
			<div class="load-more__wrap">
				<button class="load-more__item" data-page="1" id="load-more">
					<?php _e('LOAD MORE Posts', 'arctest') ?>
				</button>
			</div>
		</div>
	</section>
</main>

<?php
get_footer();
