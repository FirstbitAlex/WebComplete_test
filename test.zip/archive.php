<?php

/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */


get_header();
?>

<main id="primary" class="site-main">
</main>

<?php
get_footer();
