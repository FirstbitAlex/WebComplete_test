<?php
get_header();

$cat_list = get_categories([
	'post_type' => 'post',
	'hide_empty' => true
]);

$current_cat = '';
if (isset($_GET['category']) && !empty($_GET['category'])) {
	$current_cat = $_GET['category'];
}

?>

<main id="primary">
	<section>
		<div class="container">
			<h1 class="page-title">
				<?php _e('The Journal', 'arctest'); ?>
			</h1>
		</div>
	</section>

	<?php if (!empty($cat_list)) { ?>
		<section class="section section--filters">
			<div class="container">
				<nav class="filter-nav">
					<?php foreach ($cat_list as $cat) { ?>
						<a
							class="filter-nav__item <?php if (!empty($current_cat) && $current_cat == $cat->slug) echo 'active' ?>"
							href="<?php echo get_post_type_archive_link(get_post_type()) . '/?category=' . $cat->slug ?>">
							<?php echo $cat->name ?>
						</a>
					<?php } ?>
				</nav>
			</div>
		</section>
	<?php } ?>

	<section class="section">
		<div class="container">
			<div class="section-content">
				<?php if (have_posts()) { ?>
					<div class="publications-list">
						<?php while (have_posts()) {
							the_post();
							get_template_part('template-parts/content', get_post_type());
						}
						?>
					</div>
				<?php } else {
					get_template_part('template-parts/content', 'none');
				}
				?>
			</div>
		</div>
	</section>
</main>

<?php
get_footer();
