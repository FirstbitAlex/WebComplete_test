jQuery(document).ready(function ($) {

	function filterArticles(termId, page = 1) {
		$.ajax({
			url: articleAjax.ajax_url,
			type: 'POST',
			data: {
				action: 'filter_articles',
				term_id: termId || 0,
				page: page
			},
			beforeSend: function () {
				if (page === 1) {
					$('#article-list').html('<p>Загрузка...</p>');
				}
			},
			success: function (response) {
				if (page === 1) {
					$('#article-list').html(response);
				} else {
					$('#article-list').append(response);
				}

				// Скрываем кнопку, если меньше 3 постов вернулось
				if ($(response).filter('article').length < 3) {
					$('#load-more').hide();
				} else {
					$('#load-more').show();
				}
			}
		});
	}

	// click on filter or on card taxonomy
	$('.article-filter, .post__term').on('click', function () {

		var termId = $(this).data('term-id');
		$('#load-more').data('page', 1);

		console.log(termId)

		filterArticles(termId, 1);
	});

	// click on load more
	$('#load-more').on('click', function () {
		console.log("load-more")
		var page = $(this).data('page') + 1;
		var termId = $('.article-filter.active, .article-term.active').data('term-id') || 0;
		$(this).data('page', page);
		filterArticles(termId, page);
	});

});
