jQuery(function ($) {
});
